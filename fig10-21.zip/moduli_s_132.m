
clc

clear all %#ok<*CLALL>

close all



kg          = 87.83E+9; % Grain bulk modulus
ug          = 44.92E+9; % Grain shear modulus
den         = 2750;     % Density

a           = 4.56E+10; % Fitting parameters of kd
b           = 6.94E+10;
c           = 1.04E+07;

A           = 2.91E+10; % Fitting parameters of ud
B           = 3.24E+10;
C           = 3.15E+07;


kH          = 6.94E+10;
gH          = 3.24E+10;
vh          = (3*kH-2*gH)/(2*(3*kH+gH));
Eh          = 9*kH*gH/(3*kH+gH);

tp          = 0.02671;
ac          = 0.01; % Aspect ratio of the crack
%%
 % Measurements
x1=[38736.44162
5052514.418
1.00E+07
1.51E+07
2.00E+07

];

y1=[6248.6589
6331.37325
6414.0876
6419.48202
6410.49133


]; % Vp

x2=[2923.74179
5052514.418
9958854.295
1.50E+07
2.00E+07


];

y2=[3351.85848
3402.20635
3492.11325
3574.8276
3623.37733


]; % Vs

x3=[2923.74179
5016701.718
1.01E+07
1.50E+07
2.00E+07


];
y3=[5583.34782
5871.04991
6005.91026
6165.94455
6230.67752

]; % Vpdry (measured)

%% 
 % LFEM predictions
xx=[0e6
    5e6
10e6
15e6
20e6

];
yy=[6174.70 
6285.15 
6419.20 
6458.57 
6458.57 


];

%% 
 % Fitting curve of dry bulk and shear modulus
P           = (0:1e6:1e8)';
kd          = 1./((1./a-1./b).*exp(-P./c)+1./b);
ud          = 1./((1./A-1./B).*exp(-P./C)+1./B);

%%
 % Fluid 
kf          = 2.2e9;                   % Fluid bulk modulus (Pa)
eta         = 1e-3;                    % Fluid viscosity (Pa * s)

%% 

f           = 1e6; % Frequency
w           = 2*pi*f;

%%

CH          = 1/kH;
thes        = 1+3*kg/ug/4;
thec        = kg*(3*kg+4*ug)/(pi*ac*ug*(3*kg+ug));
faic0       = (kH-kd(1))/(kH*thec);
faic        = faic0.*exp(-thec*P*CH);

%% 

kmf1        = (1./kH)+1./((1./((1./kd)-(1./kH)))+(1./((3*1i*w*eta)./(8.*faic.*ac))));
kmf         = 1./kmf1;
umf1        = 1./ud-(4/15).*(1./kd-1./kmf);
umf         = 1./umf1;
ks1         = 1./kg+tp.*(1./kf-1./kg)./(1+tp.*(1./kf-1./kg)./(1./kmf-1./kg));
ks          = 1./ks1;
ks2         = complex(real(ks), imag(ks));
us          = umf;

%% 

vpg         = sqrt((ks+4/3.*us)./den); % Gurevich (2010)
vsg         = sqrt(us./den);

vpg2        = sqrt((kd+4/3.*ud)./den); % Dry
vsg2        = sqrt(ud./den);

%%
 % P-wave velocity rate of increase
B1          = numel(y1);
for i=1:1:B1-1
y11(i)      = (y1(i+1)-y1(i))/y1(i);
end
y11         = y11';
y11         = padarray(y11,1,'pre'); % Measurements


d2          = real([vpg(1),vpg(6),vpg(11),vpg(16),vpg(21)]);
B2          = numel(d2);
for i=1:1:B2-1
d21(i)      = (d2(i+1)-d2(i))/d2(i);
end
d21         = d21';
d21         = padarray(d21,1,'pre'); % Gurevich (2010)


B3          = numel(y3);
for i=1:1:B3-1
y31(i)      = (y3(i+1)-y3(i))/y3(i);
end
y31         = y31';
y31         = padarray(y31,1,'pre'); % Vp dry


B4          = numel(yy);
for i=1:1:B4-1
yy4(i)      = (yy(i+1)-yy(i))/yy(i);
end
yy4         = yy4';
yy4         = padarray(yy4,1,'pre'); % LFEM predictions

%% 

figure(1)

xy1 = plot(x1/10^6,            y1,'or',...
    'LineWidth',2); hold on;     % Measurements
xy2 = plot(P/10^6,      real(vpg),'-g',...
    'LineWidth',2); hold on;     % Gurevich (2010)
xy3 = plot(P/10^6,           vpg2,'-m',...
    'LineWidth',2); hold on;     % Vpdry
xy4 = plot(xx/10^6,            yy,'ob',...
    'LineWidth',2); hold on;     % LFEM predictions

xlim([0 24]); ylim([5500 6700]);hold on;

legend([xy1(1),xy2(1),xy3(1),xy4(1)],'Measured-100%','Gurevich (2010)','Measured-0%','LFRM',...
      'Location','southeast');hold on;

%% 

figure(2)
xy5 = plot(x1/10^6,            y11,'-or',...
    'LineWidth',2); hold on;      % Measurements
xy6 = plot(xx/10^6,            d21,'-og',...
    'LineWidth',2); hold on;      % Gurevich (2010)
xy7 = plot(x3/10^6,            y31,'-om',...
    'LineWidth',2); hold on;      % Vpdry 
xy8 = plot(xx/10^6,            yy4,'-ob',...
    'LineWidth',2); hold on;      % LFEM predictions

xlim([-4 24]); ylim([-0.007 0.058]);hold on;

legend([xy5(1),xy6(1),xy7(1),xy8(1)],'Measured-100%','Gurevich (2010)','Measured-0%','LFRM',...
      'Location','northeast');hold on;

%%

figure(1)
xlabel('  Pressure (MPa)','fontsize',12); ylabel('Vp (m/s)','fontsize',12);

figure(2)
xlabel('  Pressure (MPa)','fontsize',12); ylabel('P-wave velocity rate of increase','fontsize',12);
