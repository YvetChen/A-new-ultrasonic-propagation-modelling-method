
clc

clear all %#ok<*CLALL>

close all



kg          = 76.8E+9;  % Grain bulk modulus
ug          = 32E+9;    % Grain shear modulus
den         = 2674;     % Density

a           = 4.36E+10; % Fitting parameters of kd
b           = 6.90E+10;
c           = 4.23E+07;

A           = 2.08E+10; % Fitting parameters of ud
B           = 2.65E+10;
C           = 7.17E+06;


kH          = 6.90E+10;
gH          = 2.65E+10;
vh          = (3*kH-2*gH)/(2*(3*kH+gH));
Eh          = 9*kH*gH/(3*kH+gH);

tp          = 0.04391;
ac          = 0.01; % Aspect ratio of the crack
%%
 % Measurements
x1=[5175849.959
9966776.297
1.52E+07
2.01E+07
2.52E+07
3.00E+07
3.51E+07
4.00E+07
6.02E+07

];

y1=[5689.98923
5785.95123
5824.47062
5841.49358
5860.21884
5890.86017
5894.26476
5885.75328
5986.18875


]; % Vp

x2=[5091054.802
1.01E+07
1.50E+07
2.02E+07
2.51E+07
3.00E+07
3.52E+07
3.99E+07
4.53E+07
5.02E+07
5.51E+07
6.01E+07

];

y2=[2739.91018
2850.55942
2894.81912
2932.26963
2964.61326
2990.1477
3005.46836
3024.19362
3041.21658
3046.32347
3059.94184
3085.47628


]; % Vs

x3=[5091054.802
9966776.297
1.53E+07
2.01E+07
2.51E+07
3.02E+07
3.53E+07
4.06E+07
4.53E+07

];
y3=[5364.85069
5473.79764
5572.53081
5632.11117
5672.96627
5751.69945
5824.47062
5846.60047
5885.75328

]; % Vpdry (measured)

%% 
 % LFEM predictions
xx=[5e6
10e6
15e6
20e6
25e6
30e6
35e6
40e6
];
yy=[5650.50 
5741.40 
5805.82 
5815.82 
5825.82 
5855.10 
5878.42 
5898.60 

];

%% 
 % Fitting curve of dry bulk and shear modulus
P           = (0:1e6:1e8)';
kd          = 1./((1./a-1./b).*exp(-P./c)+1./b);
ud          = 1./((1./A-1./B).*exp(-P./C)+1./B);

%%
 % Fluid 
kf          = 2.2e9;                   % Fluid bulk modulus (Pa)
eta         = 1e-3;                    % Fluid viscosity (Pa * s)

%% 

f           = 1e6; % Frequency
w           = 2*pi*f;

%%

CH          = 1/kH;
thes        = 1+3*kg/ug/4;
thec        = kg*(3*kg+4*ug)/(pi*ac*ug*(3*kg+ug));
faic0       = (kH-kd(1))/(kH*thec);
faic        = faic0.*exp(-thec*P*CH);

%% 

kmf1        = (1./kH)+1./((1./((1./kd)-(1./kH)))+(1./((3*1i*w*eta)./(8.*faic.*ac))));
kmf         = 1./kmf1;
umf1        = 1./ud-(4/15).*(1./kd-1./kmf);
umf         = 1./umf1;
ks1         = 1./kg+tp.*(1./kf-1./kg)./(1+tp.*(1./kf-1./kg)./(1./kmf-1./kg));
ks          = 1./ks1;
ks2         = complex(real(ks), imag(ks));
us          = umf;

%% 

vpg         = sqrt((ks+4/3.*us)./den); % Gurevich (2010)
vsg         = sqrt(us./den);

vpg2        = sqrt((kd+4/3.*ud)./den); % Dry
vsg2        = sqrt(ud./den);

%%
 % P-wave velocity rate of increase
B1          = numel(y1);
for i=1:1:B1-1
y11(i)      = (y1(i+1)-y1(i))/y1(i);
end
y11         = y11';
y11         = padarray(y11,1,'pre'); % Measurements


d2          = real([vpg(6),vpg(11),vpg(16),vpg(21),vpg(26),vpg(31),vpg(36),vpg(41)]);
B2          = numel(d2);
for i=1:1:B2-1
d21(i)      = (d2(i+1)-d2(i))/d2(i);
end
d21         = d21';
d21         = padarray(d21,1,'pre'); % Gurevich (2010)


B3          = numel(y3);
for i=1:1:B3-1
y31(i)      = (y3(i+1)-y3(i))/y3(i);
end
y31         = y31';
y31         = padarray(y31,1,'pre'); % Vp dry


B4          = numel(yy);
for i=1:1:B4-1
yy4(i)      = (yy(i+1)-yy(i))/yy(i);
end
yy4         = yy4';
yy4         = padarray(yy4,1,'pre'); % LFEM predictions

%% 

figure(1)

xy1 = plot(x1/10^6,            y1,'or',...
    'LineWidth',2); hold on;     % Measurements
xy2 = plot(P/10^6,      real(vpg),'-g',...
    'LineWidth',2); hold on;     % Gurevich (2010)
xy3 = plot(P/10^6,           vpg2,'-m',...
    'LineWidth',2); hold on;     % Vpdry
xy4 = plot(xx/10^6,            yy,'ob',...
    'LineWidth',2); hold on;     % LFEM predictions

xlim([0 60]); ylim([5000 6100]);hold on;

legend([xy1(1),xy2(1),xy3(1),xy4(1)],'Measured-100%','Gurevich (2010)','Measured-0%','LFRM',...
      'Location','southeast');hold on;

%% 

figure(2)
xy5 = plot(x1/10^6,            y11,'-or',...
    'LineWidth',2); hold on;      % Measurements
xy6 = plot(xx/10^6,            d21,'-og',...
    'LineWidth',2); hold on;      % Gurevich (2010)
xy7 = plot(x3/10^6,            y31,'-om',...
    'LineWidth',2); hold on;      % Vpdry 
xy8 = plot(xx/10^6,            yy4,'-ob',...
    'LineWidth',2); hold on;      % LFEM predictions

xlim([0 44]); ylim([-0.004 0.025]);hold on;

legend([xy5(1),xy6(1),xy7(1),xy8(1)],'Measured-100%','Gurevich (2010)','Measured-0%','LFRM',...
      'Location','northeast');hold on;

%%

figure(1)
xlabel('  Pressure (MPa)','fontsize',12); ylabel('Vp (m/s)','fontsize',12);

figure(2)
xlabel('  Pressure (MPa)','fontsize',12); ylabel('P-wave velocity rate of increase','fontsize',12);
