
clc

clear all %#ok<*CLALL>

close all



kg          = 76.8E+9;  % Grain bulk modulus
ug          = 32E+9;    % Grain shear modulus
den         = 2539;     % Density

a           = 2.29E+10; % Fitting parameters of kd
b           = 3.35E+10;
c           = 6.18E+06;

A           = 1.14E+10; % Fitting parameters of ud
B           = 1.65E+10;
C           = 1.10E+07;


kH          = 3.35E+10;
gH          = 1.65E+10;
vh          = (3*kH-2*gH)/(2*(3*kH+gH));
Eh          = 9*kH*gH/(3*kH+gH);

tp          = 0.04092;
ac          = 0.01; % Aspect ratio of the crack
%%
 % Measurements
x1=[5114717.536
1.04E+07
1.54E+07
2.03E+07
2.52E+07
3.03E+07
3.54E+07
4.04E+07

];

y1=[5244.95929
5412.31678
5545.37118
5602.543
5642.04353
5697.13637
5744.95279
5773.01896

]; % Vp

x2=[5382357.366
1.03E+07
1.53E+07
2.02E+07
2.52E+07
3.02E+07
3.54E+07
4.02E+07
4.54E+07
5.02E+07

];

y2=[2576.59478
2698.21482
2752.26817
2804.24255
2815.67691
2846.86154
2907.15181
2913.38874
2924.8231
2959.12619

]; % Vs

x3=[5203930.813
1.01E+07
1.52E+07
2.05E+07
2.52E+07
3.05E+07
3.53E+07
4.04E+07


];
y3=[4947.66585
5244.95929
5354.10548
5429.98807
5518.34451
5581.75325
5608.77992
5638.92506


]; % Vpdry (measured)

%% 
 % LFEM predictions
xx=[5e6
10e6
15e6
20e6
25e6
30e6
35e6
40e6
];
yy=[5272.60 
5435.49 
5562.12 
5631.44 
5666.57 
5733.43 
5782.15 
5799.58 

];

%% 
 % Fitting curve of dry bulk and shear modulus
P           = (0:1e6:1e8)';
kd          = 1./((1./a-1./b).*exp(-P./c)+1./b);
ud          = 1./((1./A-1./B).*exp(-P./C)+1./B);

%%
 % Fluid 
kf          = 2.2e9;                   % Fluid bulk modulus (Pa)
eta         = 1e-3;                    % Fluid viscosity (Pa * s)

%% 

f           = 1e6; % Frequency
w           = 2*pi*f;

%%

CH          = 1/kH;
thes        = 1+3*kg/ug/4;
thec        = kg*(3*kg+4*ug)/(pi*ac*ug*(3*kg+ug));
faic0       = (kH-kd(1))/(kH*thec);
faic        = faic0.*exp(-thec*P*CH);

%% 

kmf1        = (1./kH)+1./((1./((1./kd)-(1./kH)))+(1./((3*1i*w*eta)./(8.*faic.*ac))));
kmf         = 1./kmf1;
umf1        = 1./ud-(4/15).*(1./kd-1./kmf);
umf         = 1./umf1;
ks1         = 1./kg+tp.*(1./kf-1./kg)./(1+tp.*(1./kf-1./kg)./(1./kmf-1./kg));
ks          = 1./ks1;
ks2         = complex(real(ks), imag(ks));
us          = umf;

%% 

vpg         = sqrt((ks+4/3.*us)./den); % Gurevich (2010)
vsg         = sqrt(us./den);

vpg2        = sqrt((kd+4/3.*ud)./den); % Dry
vsg2        = sqrt(ud./den);

%%
 % P-wave velocity rate of increase
B1          = numel(y1);
for i=1:1:B1-1
y11(i)      = (y1(i+1)-y1(i))/y1(i);
end
y11         = y11';
y11         = padarray(y11,1,'pre'); % Measurements


d2          = real([vpg(6),vpg(11),vpg(16),vpg(21),vpg(26),vpg(31),vpg(36),vpg(41)]);
B2          = numel(d2);
for i=1:1:B2-1
d21(i)      = (d2(i+1)-d2(i))/d2(i);
end
d21         = d21';
d21         = padarray(d21,1,'pre'); % Gurevich (2010)


B3          = numel(y3);
for i=1:1:B3-1
y31(i)      = (y3(i+1)-y3(i))/y3(i);
end
y31         = y31';
y31         = padarray(y31,1,'pre'); % Vp dry


B4          = numel(yy);
for i=1:1:B4-1
yy4(i)      = (yy(i+1)-yy(i))/yy(i);
end
yy4         = yy4';
yy4         = padarray(yy4,1,'pre'); % LFEM predictions

%% 

figure(1)

xy1 = plot(xx/10^6,            y1,'or',...
    'LineWidth',2); hold on;     % Measurements
xy2 = plot(P/10^6,      real(vpg),'-g',...
    'LineWidth',2); hold on;     % Gurevich (2010)
xy3 = plot(P/10^6,           vpg2,'-m',...
    'LineWidth',2); hold on;     % Vpdry
xy4 = plot(xx/10^6,            yy,'ob',...
    'LineWidth',2); hold on;     % LFEM predictions

 xlim([0 60]); ylim([3700 5950]);hold on;

legend([xy1(1),xy2(1),xy3(1),xy4(1)],'Measured-100%','Gurevich (2010)','Measured-0%','LFRM',...
      'Location','southeast');hold on;

%% 

figure(2)
xy5 = plot(x1/10^6,            y11,'-or',...
    'LineWidth',2); hold on;      % Measurements
xy6 = plot(x1/10^6,            d21,'-og',...
    'LineWidth',2); hold on;      % Gurevich (2010)
xy7 = plot(x1/10^6,            y31,'-om',...
    'LineWidth',2); hold on;      % Vpdry 
xy8 = plot(x1/10^6,            yy4,'-ob',...
    'LineWidth',2); hold on;      % LFEM predictions

xlim([0 44]); ylim([-0.004 0.065]);hold on;

legend([xy5(1),xy6(1),xy7(1),xy8(1)],'Measured-100%','Gurevich (2010)','Measured-0%','LFRM',...
      'Location','northeast');hold on;

%%

figure(1)
xlabel('  Pressure (MPa)','fontsize',12); ylabel('Vp (m/s)','fontsize',12);

figure(2)
xlabel('  Pressure (MPa)','fontsize',12); ylabel('P-wave velocity rate of increase','fontsize',12);
